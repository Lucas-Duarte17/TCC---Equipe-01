<?php
// inicializa a sessão
session_start();

// verifica se o usuário está logado, se não estiver redireciona para a página de login
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../cadastro/register.php");
    exit;
}
?>
<?php include "./inc/header.php"; ?>
<br>
<div class="perfil">
<h1>Olá, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>.</h1>
</div><hr>
<div class="centralizado">
  <div class="container3">
    <a href="./editperfil/index.php" class="btn btn-primary">Inserir Informações Extras</a>
    <a href="../cadastro/reset-password.php" class="btn btn-warning">Troque sua senha</a>
    <a href="../cadastro/logout.php" class="btn btn-danger">Faça logout de sua conta</a>
    <a href="http://localhost/desenvolvimento/dsweb0301/PERFILcrud/customers/view.php?id=7" class="btn btn-dark">Informações extras</a>
  </div><hr>
  <div class="container3">
    <a href="playground.php" class="btn btn-success">Playground</a>
    <a href="mural.php" class="btn btn-success">Mural</a>
    <a href="downlond.php" class="btn btn-success">Download de Livros</a>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
