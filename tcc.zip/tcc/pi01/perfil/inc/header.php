<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <title>Perfil - PS+</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../bootstrap/500/css/bootstrap.min.css">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/carousel/">
    <link rel="stylesheet" href="../css/estilo.css">
    <script type ="text/javascript" src="../js/scripts.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/5.0.0/css/font-awesome.min.css">
</head>
<body>
  <!-- MENU  -->
  <nav class="navbar navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="../index.php">
        <img src="../img/logo.png" alt="" width="30" height="30">
        Para Saber <span style="color:#34AAFF">Mais</span>
      </a>
      <ul class="nav justify-content-end">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Perfil</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Matérias
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="../materias/matematica.php">Matemática</a></li>
            <li><a class="dropdown-item" href="../materias/fisica.php">Física</a></li>
            <li><a class="dropdown-item" href="../materias/quimica.php">Química</a></li>
            <li><a class="dropdown-item" href="../materias/biologia.php">Biologia</a></li>
            <li><a class="dropdown-item" href="../materias/portugues.php">Português</a></li>
            <li><a class="dropdown-item" href="../materias/literatura.php">Literatura</a></li>
            <li><a class="dropdown-item" href="../materias/historia.php">História</a></li>
            <li><a class="dropdown-item" href="../materias/geografia.php">Geografia</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../contato/index.php">Contato</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../qsomos.php">Quem Somos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../help.php">Help</a>
        </li>
      </ul>
    </div>
      <img src="../img/menu.png" alt="" width="100%">
    </nav>
  <main>
