<?php include "./inc/header.php"; ?>
<!DOCTYPE html>
<html lang="pt-br" >
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div id="center">
  <div id="game">
    <div id="maze">
      <div id="end"></div>
    </div>
    <div id="joystick">
      <div class="joystick-arrow"></div>
      <div class="joystick-arrow"></div>
      <div class="joystick-arrow"></div>
      <div class="joystick-arrow"></div>
      <div id="joystick-head"></div>
    </div>
    <div id="note">
      Clique no controlador para começar!
      <p>Mova as bolas, depois de juntas, para o centro. Preparado para o modo difícil? Aperte H
    </div>
  </div>
</div>
<!-- partial -->
  <script  src="./script.js"></script>
<?php include "./inc/footer.php"; ?>
