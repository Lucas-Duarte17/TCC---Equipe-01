<?php include "./inc/header.php"; ?>
<h3>Literaturs</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Trovadorismo
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Foi o primeiro movimento dentro das escolas literárias. O trovadorismo se baseou na literatura e
        poesia, durante o século XI, na idade média. Teve início na Europa, e deu o ponta pé inicial para as seguintes manifestações literárias.
        O trovadorismo surgiu com o fim do Império Romano (destruído no século V com a invasão dos bárbaros, vindos do norte da Europa), e perdurou até o século XV.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Humanismo
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Esse período retrata o que o próprio nome diz: o homem e a sua valorização. Surge mais atenção à natureza humana.
        A literatura mantém características religiosas, mas vem pra dar atenção a uma das maiores criações de Deus, a humanidade. Na Itália,
        destacam-se grandes artistas como: Dante Alighieri autor da Divina Comédia, Giovanni Bocaccio e Francesco Petrarca. Em Portugal,
        destaca-se o teatro do poeta de Gil Vicente autor de A Farsa de Inês Pereira.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Classicismo
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O racionalismo impera nesse período, que gerou muitas reflexões em toda sociedade, principalmente nos artistas.
        O individual é deixado de lado e pensamentos mais amplos sobre as verdades universal são foco de discussão.
        O período é caracterizado também pela valorização da cultura greco-romana. Destacam-se os franceses François Rabelais e Michel de Montaigne.
        Na Inglaterra, o poeta de maior sucesso foi William Shakespeare se destaca na poesia lírica e no teatro. Na Espanha,
        Miguel de Cervantes cria novelas humoristicas e cria o personagem Dom Quixote e seu escudeiro, Sancho Pança, na famosa obra Dom Quixote de La Mancha.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Quinhentismo
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Neste período foi retratado todos os aspectos sobre o descobrimento do Brasil. Desde a chegada da frota
        comandada por Pedro Álvares Cabral à localidade da Ilha de Vera Cruz, ocorrida no dia 22 de abril de 1500. Durante esse trecho das escolas literárias,
        foram escritas cartas, crônicas e sermões.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Barroco
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Em meio a um período em que a arte ganha espaço, e a filosofia passa a questionar a existência do homem entre
        outros conflitos existenciais. Dentre as escolas literárias essa é a que surge com a proposta de fazer com que o homem redescubra sua fé.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Arcadismo
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Essa escola literária vem com a proposta de conectar o homem à natureza através da arte. Sua essência é baseada no
        resgate da antiguidade clássica, que não separava a arte da técnica. O processo não estaria ligado diretamente a habilidade, mas sim ao saber fazer,
        e isso difundia-se.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Romantismo
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">É marcado pela expressão e valorização dos sentimentos, destaque para dualidade entre o amor e o sofrimento.
        A liberdade para criar ganha espaço lado a lado com a fantasia.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        Realismo
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Primeiro ideal que aponta o homem como fruto do meio. Esse movimento critica o capitalismo, a valorização
        extrema ao dinheiro, e busca descrever o homem de forma real, como um ser que tem qualidades e defeitos. Entende-se que nem sempre o mal
        faz parte do homem, mas sim do estimulo que ele recebe do meio. Principais representantes: Gustave Flaubert autor de Madame Bovary,
        Charles Dickens (Oliver Twist e David Copperfield), Charlotte Brontë (Jane Eyre), Emily Brontë (O Morro dos Ventos Uivantes),
        Fiodor Dostoievski, Leon Tolstoi, Eça de Queiroz, Cesário Verde, Antero de Quental e Émile Zola, Eugênio de Castro,
        Camilo Pessanha, Arthur Rimbaud, Charles Baudelaire.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
        Naturalismo
      </button>
    </h2>
    <div id="flush-collapseNine" class="accordion-collapse collapse" aria-labelledby="flush-headingNine" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">No mesmo período em que o realismo entrou em ascensão, o naturalismo também surgiu. Os conceitos de ambos se interligam,
        porém com algumas ressalvas. O naturalismo também prega que o homem é fruto do meio em que vive e que a natureza do ser se modifica
        de acordo com os incentivos que recebe. A principal diferença é que no romance realista, a classe alta é a pensante e
        traz mais características da mesma. Já o romance naturalista retrata a comunidade mais pobre. O livro O
        Cortiço de Aluísio de Azevedo descreve bem essas manifestações.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTen">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTen" aria-expanded="false" aria-controls="flush-collapseTen">
        Parnasianismo
      </button>
    </h2>
    <div id="flush-collapseTen" class="accordion-collapse collapse" aria-labelledby="flush-headingTen" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Marcado por uma arte rebuscada e uma linguagem singular e mais refinada, essa escola literária produzia rimas ricas.
        O parnasianismo é uma contradição ao romantismo, ele busca retratar a realidade dos fatos sem enfeites e possibilidades.
        Os poetas deixam de lado a emoção e a própria interpretação sobre os fatos, analisando de uma maneira mais imparcial.
        A estética é muito valorizada nessa escola.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEleven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEleven" aria-expanded="false" aria-controls="flush-collapseEleven">
        Simbolismo
      </button>
    </h2>
    <div id="flush-collapseEleven" class="accordion-collapse collapse" aria-labelledby="flush-headingEleven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Essa é uma época onde os conceitos de todas as escolas citadas começam a se dissolver, já introduzindo o
        pré-modernismo. O simbolismo busca uma série de novos conceitos sociais como a fé, a religião, as crenças.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwelve">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwelve" aria-expanded="false" aria-controls="flush-collapseTwelve">
        Modernismo
      </button>
    </h2>
    <div id="flush-collapseTwelve" class="accordion-collapse collapse" aria-labelledby="flush-headingTwelve" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Entre as escolas literárias essa foi uma das que iniciaram com maior marco e com maior traço característico de sua essência.
        Marcada pelo início da semana de arte moderna, em 1922, o modernismo deu uma nova cara a linguagem, com muita liberdade de criação sem apego ao passado.
        Um novo conceito artístico também surgiu. Os artistas que mais exploraram essas possibilidades do modernismo foram
        Carlos Drummond de Andrade e João Cabral de Melo Neto (um mais lírico, outro mais objetivo, concreto),
        pelos romancistas de 30, na prosa intimista de Clarice Lispector.
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
