</main> <!-- /container -->
<nav class="navbar fixed-bottom navbar-dark bg-dark text-muted">
  <div class="container-fluid">
    <p class="d-none d-sm-block d-sm-none d-md-block"></p><br>
  </div>
</nav>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo BASEURL; ?>js/jquery-1.11.2.min.js"><\/script>')</script>
  <script src="../bootstrap/500/js/bootstrap.min.js"></script>
</body>
</html>
