<?php include "./inc/header.php"; ?>
<div class="banner">
  <img src="./img/imgqsomos.png" alt="" class="d-none d-lg-block">
</div><hr>
<div class="container4">
  <div class="row topic qsomos">
    <div class="col-md-6">
      <img src="./img/logo.png" alt="" class="logoqs"><br>
    </div>
    <div class="col-md-6 text6">
      <h1 style="color: #33aafe">Quem Somos?</h1>
      <p>Nós da empresa "Para Saber Mais Conteúdos Digitais Ltda." somos uma equipe naturalmete curiosa, que está sempre buscando novos ensinamentos e perspectivas.
        Nossa missão é tornar a educação mais acessível a todos e, dessa forma, contribuir para a formação de uma sociedade mais consciente.
        Temos mais de 35 anos de experiência aprendendo e ensinando novos conhecimentos.<br>Continue lendo <span style="color: #33aafe">Para Saber Mais</span>!</p>
    </div>
  </div>
  <div class="row topic">
    <div class="col-md-3">
      <img src="./img/ampulheta.png" alt="" class="imgcont">
      <h4>Nossa história</h4>
      <p>Em 1972, quatro jovens estudantes do Curso de Letras da Faculdade de Ciências Sociais de São João Nepomuceno definiram
        como uma das metas de suas vidas o incentivo da leitura para crianças, jovens e adultos como forma de ampliar os horizontes
        das pessoas bem como incentivar a imaginação e a criatividade dos mesmos.</p>
    </div>
    <div class="col-md-9">
      <img src="./img/jovens.png" alt="" width="100%" class="d-none d-lg-block">
    </div>
  </div>
  <div class="row topic">
    <div class="col-md-12">
      <p>Assim, em 25/02/1972 surgia, em um espaço da garagem da casa dos pais de um dos jovens, a
         “Para Saber Mais Biblioteca Comunitária” com um pequeno acervo físico arrecadado pelos jovens
        fundadores: Machado de Alencar, José de Assis, Cecília de Queiroz e Rachel Meireles.
      <br>Como lema da nova Biblioteca escolheram as palavras em latim “Legit.Somniare.Implerem.” que
         significam “Ler. Sonhar. Realizar”.</p>
      <p>E este lema impulsionou a biblioteca em todos os seus dias, tanto é que o sonho tornou-se maior
         na medida em que conseguiram adquirir uma nova sede, uma pequena sala no centro da cidade,
         através de uma doação em reconhecimento ao trabalho voluntário que faziam na comunidade.Como
         todos percebiam que o trabalho era sério e comprometido a comunidade abraçou a ideia e
         sempre contribuiu com a biblioteca.</p>
      <p>À medida que o tempo passou, várias foram as atividades desenvolvidas em conjunto com escolas e
         cursos de forma a incentivar a leitura e o conhecimento e com muito esforço tanto o local quanto o
         acervo foi expandido, bem como a atuação da biblioteca na comunidade.</p>
      <p>Atualmente, a segunda geração das famílias dos fundadores encontra-se engajada voluntariamente
         no sonho criado em 1972, e como diz o lema o sonho é acompanhar a modernidade e a realização
         será a utilização da internet como forma de disseminar a leitura e a cultura.</p>
    </div>
  </div>
  <div class="row topic">
    <div class="col-md-3 order-md-2">
      <img src="./img/certificado-de-garantia.png" alt="" class="imgcont">
      <h4>Nosso Legado</h4>
      <p>Dessa forma pretendemos lançar um Portal de Conteúdo Educacional para apoiar estudantes em
         sua jornada acadêmica, bem como de oferecer conteúdo de qualidade para pessoas que busquem
         ampliar seus <span style="color: #33aafe">conhecimentos</span>.</p>
      <p>Esta é a realidade que a “Para Saber Mais Conteúdos Digitais” está iniciando!!!!!<br><span style="color:#33aafe">E que venham novos Sonhos</span>!!!!</p>
      <p></p>
    </div>
    <div class="col-md-9 order-md-1">
      <img src="./img/siteqs.png" alt="" width="100%" class="d-none d-lg-block">
    </div>
  </div>
  <br>
</div>
<div class="loc">
  <h1 style="color: #33aafe">Onde estamos?</h1>
  <img src="./img/placeholder.png" alt="" class="imgcont">
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3711.607739176009!2d-43.0134092!3d-21.5230793!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xa2926ff693c449%3A0xb15620c7671afbb!2sCentro%20Integrado%20Sesi-Senai%20Robson%20Braga%20de%20Andrade!5e0!3m2!1spt-BR!2sbr!4v1616027869431!5m2!1spt-BR!2sbr"
  width="100%" height="500px" style="border:5px solid #ccc;" allowfullscreen="" loading="lazy"></iframe>
  <div class="infloc">
    <p><b>Centro Integrado Sesi-Senai Robson Braga de Andrade</b></p>
    <p>R. Roberto Schincariol, 81 - Distrito Industrial, <br>São João Nepomuceno - MG, 36680-000</p>
  </div>
</div><br>
<?php include "./inc/footer.php"; ?>
