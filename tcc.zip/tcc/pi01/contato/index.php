<?php include "./inc/header.php"; ?>
<form action="app.php" class="formulario" method="POST">
    <div class="mb-3">
      <label for="nome" class="form-label secondary">Nome</label>
      <input type="text" name="nome" class="form-control" id="exampleFormControlInput1" placeholder="ex: José Fulano">
    </div>
    <div class="mb-3">
      <label for="nome" class="form-label secondary">Telefone</label>
      <input type="text" name="telefone" class="form-control" id="exampleFormControlInput1" placeholder="ex: (XX)XXXXX-XXXX">
    </div>
    <div class="mb-3">
      <label for="nome" class="form-label secondary">Email</label>
      <input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="ex: josefulano@gmail.com">
    </div>
    <div class="mb-3">
      <label for="mensagem" class="form-label secondary">Mensagem</label>
      <textarea name="mensagem" class="form-control" id="exampleFormControlTextarea1" placeholder="ex: mensagem" rows="3"></textarea>
    </div>
    <input class="btn btn-outline-secondary" type="submit" value="Enviar">
    <div class="g-recaptcha" data-sitekey="6LcBEz8aAAAAACBtxpIbiETWfrWE7_RDjCiBtUq6"></div>

  </form>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo BASEURL; ?>js/jquery-1.11.2.min.js"><\/script>')</script>
  <script src="./bootstrap/500/js/bootstrap.min.js"></script>
</body>
</html>
<?php include "./inc/footer.php"; ?>
