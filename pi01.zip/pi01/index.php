<?php include "./inc/header.php"; ?>
<!-- ANIMAÇÃO COM LOGO -->
<div class="banner">
  <video autoplay muted loop>
    <source src="./video/animacao.mp4" type="video/mp4">
    </video>
  </div>
  <!-- BOAS-VINDAS DO SITE -->
	<div class="container1 d-none d-lg-block">
    <div class="a"></div><div class="b"></div><div class="c"></div><div class="d"></div>
    <div class="e"></div><div class="f"></div><div class="g"></div><div class="h"></div>
    <div class="conteudo"><br>
      <h4 class="fw-lighter">ParaSaberMais é um portal educacional responsivo para todos os usuários</h2>
      <h5 class="fw-lighter">Nossa intenção é espalhar o conhecimento de maneira gratuita</h4><br>
      <h6 class="fw-bolder">Bons estudos!</h6><br>
    </div>
	</div>
  <!-- DOWNLOAD, APRENDIZAGEM E CONHECIMENTO -->
  <div class="row align-items-start">
    <div class="col">
      <img src="./img/down-arrow.png" alt="" class="imgcont">
      <h5>DOWNLOAD DE LIVROS</h5>
      <p>A plataforma disponibiliza livros online de maneira gratuita para os usuários</p>
    </div>
    <div class="col">
      <img src="./img/devices.png" alt="" class="imgcont">
      <h5>APRENDIZAGEM ONLINE</h5>
      <p>As matérias escolares estão disponíveis para todos que se interessarem pelo site</p>
    </div>
    <div class="col">
      <img src="./img/globo.png" alt="" class="imgcont">
      <h5>CONHECIMENTOS DIVERSOS</h5>
      <p>o site oferece 6 matérias com diferentes temas, além de fórmulas interativas</p>
    </div>
  </div>
  <div class="d-none d-lg-block">
    <a href="./perfil/index.php"><img src="./img/cadastrar.png" alt="" width="100%" height="auto"></a>
  </div><br>
  <!-- APRESENTAÇÃO DAS MATÉRIAS -->
  <div class="container3">
    <a href="./materias/matematica.php">
      <div class="card card-1 mat">
        <h4>MATEMÁTICA</h4>
        <img src="./img/matematica.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/fisica.php">
      <div class="card card-1 mat">
        <h4>FÍSICA</h4>
        <img src="./img/fisica.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/quimica.php">
      <div class="card card-1 mat">
        <h4>QUÍMICA</h4>
        <img src="./img/quimica.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/biologia.php">
      <div class="card card-1 mat">
        <h4>BIOLOGIA</h4>
        <img src="./img/biologia.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/portugues.php">
      <div class="card card-1 mat">
        <h4>PORTUGUÊS</h4>
        <img src="./img/portugues.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/literatura.php">
      <div class="card card-1 mat">
        <h4>LITERATURA</h4>
        <img src="./img/literatura.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/historia.php">
      <div class="card card-1 mat">
        <h4>HISTÓRIA</h4>
        <img src="./img/historia.png" alt="" width="150px" height="150px">
      </div>
    </a>
    <a href="./materias/geografia.php">
      <div class="card card-1 mat">
        <h4>GEOGRAFIA</h4>
        <img src="./img/geografia.png" alt="" width="150px" height="150px">
      </div>
    </a>
</div><hr>
  <!-- DESCRIÇÃO  DAS FERRAMENTAS OFERECIDAS -->
  <div class="container4">
    <div class="row topic">
      <div class="col-md-4">
        <img src="./img/down-arrow.png" alt="" class="imgcont">
        <h4>DOWNLOAD DE LIVROS</h4>
        <p>Além de aumentar o conhecimento, o hábito da leitura aprimora o vocabulário e ajuda na construção textual.
           Um ato de grande importância para a aprendizagem do ser humano, a leitura, além de favorecer o aprendizado de conteúdos específicos, aprimora a escrita.
           E para incentivar a leitura, aqui no PS+, você poderá fazer downloads de inúmeros livros de forma gratuita.</p>
      </div>
      <div class="col-md-8">
        <img src="./img/downlivro.png" alt="" width="100%" class="d-none d-lg-block">
      </div>
    </div>
    <br><hr>
    <div class="row topic">
      <div class="col-md-4 order-md-2">
        <img src="./img/devices.png" alt="" class="imgcont">
        <h4>APRENDIZAGEM ONLINE</h4>
        <p>A tecnologia, ainda mais nesse momento, está presente em todas as áreas da sociedade. Na educação não poderia ser diferente. Portanto, o ambiente de aprendizagem
          online ganhou muito mais espaço no ensino. E aqui, as matérias escolares estão disponíveis para todos que se interessarem pelo site</p>
      </div>
      <div class="col-md-8 order-md-1">
        <img src="./img/ead.png" alt="" width="100%" class="d-none d-lg-block">
      </div>
    </div>
    <br><hr>
    <div class="row topic">
      <div class="col-md-4">
        <img src="./img/globo.png" alt="" class="imgcont">
        <h4>CONHECIMENTOS DIVERSOS</h4>
        <p>O conhecimento é a capacidade humana de entender, apreender e compreender as coisas, além disso ele pode ser aplicado, criando e experimentando o novo.
          O conhecimento é a substantivação do verbo conhecer. Conhecer é o ato de entender, compreender, apreender algo por meio da experiência ou do raciocínio.
          E aqui, será depositado muito carinho e responsabilidade para entregar, da melhor maneira, os mais diversos conhecimentos</p>
      </div>
      <div class="col-md-8">
        <img src="./img/conhecimento.png" alt="" width="100%" class="d-none d-lg-block">
      </div>
    </div>
    <br><hr>
  </div>
<?php include "./inc/footer.php"; ?>
