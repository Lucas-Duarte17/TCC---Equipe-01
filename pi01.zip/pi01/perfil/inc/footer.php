</main> <!-- /container -->
<footer id="myFooter" class="d-none d-lg-block">
  <div class="container">
    <div class="row">
      <div class="col-sm-4  d-none d-lg-block">
        <img src="../img/logo.png" alt="" width="300px" height="300px">
      </div>
      <div class="col-sm-2"></div>
      <div class="col-sm-3">
          <h5>Inicio</h5>
          <ul>
              <li><a href="../index.php">Home</a></li>
              <li><a href="index.php">Perfil</a></li>
              <li><a href="../contato/index.php">Contato</a></li>
              <li><a href="../qsomos.php">Quem Somos</a></li>
              <li><a href="../help.php">Help</a></li>
              <li><a href="../fontes.php">Fontes</a></li>
          </ul>
      </div>
      <div class="col-sm-3">
          <h5>Matérias</h5>
          <ul>
            <li><a href="../materias/matematica.php">Matemática</a></li>
            <li><a href="../materias/fisica.php">Física</a></li>
            <li><a href="../materias/quimica.php">Química</a></li>
            <li><a href="../materias/biologia.php">Biologia</a></li>
            <li><a href="../materias/portugues.php">Português</a></li>
            <li><a href="../materias/literautra.php">Literatura</a></li>
            <li><a href="../materias/historia.php">História</a></li>
            <li><a href="../materias/geografia.php">Geografia</a></li>
          </ul>
      </div>
  </div><hr>
  <div class="col-sm-12">
      <a href="../contato/index.php">
          <button type="button" class="btn btn-default">Contato</button>
      </a>
  </div>
</div>
<nav class="navbar bottom navbar-dark bg-dark text-muted">
  <div class="container-fluid">
    <h7>Todos os Direitos Reservados ParaSaberMaisConteúdosDigitais Ltda&#169;</h7><br>
    <h7>Desenvolvido utilizando HTML, CSS, PHP e JS, pela <b>InovaTech&#169;</b></h7>
    <a href="#" id="subir" class="d-none d-lg-block">
      <div id="voltarTopo">
        <p>Voltar ao topo</p>
      </div>
    </a>
  </div>
</nav>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo BASEURL; ?>js/jquery-1.11.2.min.js"><\/script>')</script>
  <script src="../bootstrap/500/js/bootstrap.min.js"></script>
</body>
</html>
