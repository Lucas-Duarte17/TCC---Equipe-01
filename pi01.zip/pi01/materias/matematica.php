<?php include "./inc/header.php"; ?>
<h3>Matemática</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Operações básicas
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Em matemática, uma operação é qualquer tipo de procedimento que é realizado sobre certa quantidade de
        elementos, e que obedece sempre a uma mesma lógica (regra). Conforme o número de termos necessários em uma operação,
        esta pode ser classificada como operação unária, operação binária, operação ternária e assim por diante.
        <ul>
          <li>Soma = +</li>
          <li>Subtração = -</li>
          <li>Multiplicação = * ou x</li>
          <li>Divisão = /</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Área
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Área é um conceito matemático que pode ser definida como quantidade de espaço bidimensional, ou seja, de
        superfície.
        Existem várias unidades de medida de área, sendo a mais utilizada o metro quadrado (m²) e os seus múltiplos e
        sub-múltiplos. São também muito usadas as medidas agrárias: are, que equivale a cem metros quadrados; e seu múltiplo hectare,
        que equivale a dez mil metros quadrados. Outras unidades de medida de área são o acre e o alqueire. Na geografia e
        cartografia, o termo "área" corresponde à projeção num plano horizontal de uma parte da superfície terrestre.
        Assim, a superfície de uma montanha poderá ser inclinada, mas a sua área é sempre medida num plano horizontal.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Geometria Espacial
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A geometria espacial é a análise de sólidos no espaço, ou seja, é a geometria para objetos
        tridimensionais, diferente da geometria plana, que é o estudo de figuras bidimensionais. Assim como esta,
        aquela surge com base em conceitos primitivos, sendo eles: ponto, reta, plano e espaço. Com base nos elementos
        primitivos, desenvolve-se os sólidos geométricos, sendo os principais os poliedros: paralelepípedo, cubo e demais
        prismas, além dos conhecidos como sólidos de Platão; e os corpos redondos: cone, cilindro e esfera. Além do reconhecimento
        desses sólidos, é importante compreender que os cálculos de volume e de área total possuem fórmulas específicas para
        cada um dos tipos.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        PA e PG
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">PA e PG são sequências finitas ou infinitas de números que seguem uma lógica ou razão. PA é a
        sigla para progressão aritmética, enquanto PG significa progressão geométrica. A progressão aritmética é aquela sequência
        numérica em que cada termo (a partir do segundo) corresponde à soma do anterior com um valor chamado razão (r). A progressão
        geométrica (PG) não é muito diferente da PA. A ideia é a mesma: uma sequência numérica que tem uma lógica. Agora, no caso
        da PG, a razão (na PG, ela é identificada por q) não é somada ao termo anterior, mas multiplicada. </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Ângulos
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O ângulo é uma região delimitada por duas semirretas. Para medi-lo, há duas possíveis unidades:
        grau ou radiano. De acordo com a sua medida, ele pode ser classificado em agudo, reto, obtuso ou raso.
        Quando temos dois ângulos, podemos estabelecer relações entre eles. Caso eles possuam a mesma medida, eles são chamados
        de congruentes. Quando a soma entre eles é igual a 90º ou 180º ou 360º, eles são conhecidos, respectivamente, como ângulos
        complementares, suplementares e replementares.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Circunferência
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Circunferência é o conjunto de todos os pontos de um plano equidistantes de um ponto fixo, desse
        mesmo plano, denominado centro da circunferência.
        A circunferência possui características não comumente encontradas em outras figuras planas.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Trigonometria
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Trigonometria é a área da matemática que estuda as relações envolvendo os lados de um triângulo
        retângulo, que um polígono que possui três ângulos. A origem do nome vem do grego que refere-se a medidas de três ângulos.
        A partir dos lados do triângulo é que encontramos as razões seno, cosseno e tangente.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        Potenciação
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A potenciação ou exponenciação é a operação matemática que representa a multiplicação de fatores iguais. Ou seja, usamos a potenciação quando um número é multiplicado por ele mesmo várias vezes.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
        Funções
      </button>
    </h2>
    <div id="flush-collapseNine" class="accordion-collapse collapse" aria-labelledby="flush-headingNine" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Uma função é uma relação matemática estabelecida entre duas variáveis. As funções podem ser
        injetoras, sobrejetoras, bijetoras e simples. Função é uma regra que relaciona cada elemento de um conjunto (representado
        pela variável x) a um único elemento de outro conjunto (representado pela variável y). Para cada valor de x, podemos
        determinar um valor de y, dizemos então que “y está em função de x”.</div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
