<?php include "./inc/header.php"; ?>
<h3>História</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Teorias da História
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Historiografia pode parecer uma palavra complicada, mas nada mais é que a ciência ligada ao estudo da História.
        Com um entendimento sobre o tema, você domina a construção do conhecimento histórico.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Antropologia Cultural
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Saber como os seres humanos mudaram a cultura é fundamental para compreender muitos fatos. Essa matéria
        explora esse ponto a fundo e mostra as várias formas de manifestação da diversidade cultural.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        História Antiga
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Desde Roma e Grécia até o período atual, bastante coisa aconteceu. Mas também foi há vários séculos que diversos
        conceitos surgiram e se desenvolveram — como os Jogos Olímpicos da Antiguidade, a ideia de democracia e até as cidades. Ao estudar História Antiga,
        você conhece esses pilares importantes da ocupação humana.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        História das Religiões
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Desde o começo da civilização, a religião é uma questão importante para uma grande parcela da sociedade.
        Como são muitas as vertentes que dominaram as épocas, essa disciplina apresenta o desenvolvimento religioso e as características de cada mudança.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        História Medieval
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Também não dá para ignorar a famosa Idade das Trevas. Essa matéria traz tudo sobre o período medieval e conta como eram os
        anos feudais, dos grandes castelos europeus e das guerras sem precedentes.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        História Moderna
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">ACom o final da Idade Média, entramos no que é conhecido como História Moderna. A disciplina permite estudar o que aconteceu
        nos séculos seguintes à Idade Média, até meados de 1700. Quanto mais se aproximar do período atual, maior será a compreensão das influências do passado.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        História do Brasil
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Também não dá para deixar de fora os fatos do nosso país, não é? O aprendizado sobre o Brasil Colônia demonstra como
        foi a ocupação de Portugal após as Grandes Navegações, a divisão territorial e as mudanças impostas nas terras que eram dos indígenas.
        Com a ocupação da colônia, logo o Brasil se tornou sede do Império de Portugal. Depois, passou à condição de República. Ao conhecer todos
        os fatos, é possível entender o que nos trouxe até aqui.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        História Contemporânea
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">E por falar no presente, a matéria voltada para a parte contemporânea estuda os tempos atuais, do século 18 em
        diante. Mais que compreender o que aconteceu em um passado distante, permite analisar as transformações de agora.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
        História da África
      </button>
    </h2>
    <div id="flush-collapseNine" class="accordion-collapse collapse" aria-labelledby="flush-headingNine" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Depois de mergulhar no Velho Continente e na América, não dá para deixar a África de fora. Os estudos focam na
        configuração sociocultural africana e na relação com os outros continentes ao longo do tempo.
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
