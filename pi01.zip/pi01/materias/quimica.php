<?php include "./inc/header.php"; ?>
<h3>Química</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Estados Físicos da Matéria
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Fases ou estados da matéria são conjuntos de configurações que objetos macroscópicos podem apresentar.
        O estado físico tem relação com a velocidade do movimento das partículas de uma determinada substância. Canonicamente e
        segundo o meio em que foram estudados, são cinco os estados ou fases considerados: Sólido; Líquido; Gasoso; Plasma; Água superiônica.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Átomo
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Esse nome foi proposto pelos filósofos gregos Demócrito e Leucipo. Elementos químicos, moléculas, substâncias
        e materiais orgânicos ou inorgânicos são formados por átomos. Em sua constituição, o átomo apresenta partículas (prótons, nêutrons e elétrons),
        não sendo a menor parte da matéria.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Estequiometria
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Estequiometria é o cálculo da quantidade das substâncias envolvidas numa reação química. Este é feito com
        base nas leis das reações e é executado, em geral, com o auxílio das equações químicas correspondentes. Esta palavra, estequiometria,
        é derivada do grego: stoikheion = elemento, e metron = medida ou medição.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Gases
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Os gases são substâncias cujas moléculas perdem totalmente a atração entre si e se dispersam muito umas das outras,
        além disso, estas moléculas estão sempre em movimento desordenado. ... Um gás, seja ele qual for, pode sofrer três tipos de variação: de volume,
        temperatura e de pressão.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Funções Inorgânica
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Funções inorgânicas são os grupos de substâncias químicas que não apresentam como elemento químico central o carbono
        (já que as substâncias que o apresentam pertencem às funções orgânicas), ou seja, fazem parte da Química Inorgânica.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Funções Orgânica
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Em química orgânica, funções orgânicas são grupos de compostos orgânicos que têm comportamento químico similar,
        devido ao grupo funcional característico.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Eletroquímica
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Eletroquímica é um dos ramos da físico-química que estuda as reações que envolvem transferência de elétrons para a
        transformação de energia química em energia elétrica e vice-versa; isto é, estuda reações de oxirredução ou redox
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
