<?php include "./inc/header.php"; ?>
<h3>Geografia</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Relevo
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">É importante que os alunos tenham conhecimento sobre os processos de formação do relevo e quais são os principais
        tipos de relevo do Brasil. É necessário também ter conhecimento sobre como se deu a formação dos planaltos e montanhas.
        É necessário abordar ainda a ocupação do espaço geomorfológico brasileiro e as suas consequências.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Globalização
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">No assunto da globalização deve-se estar atento à internacionalização das relações econômicas entre os países,
        apoiadas nas novas tecnologias de comunicação e transporte. Esse processo de globalização é relacionado com o tipo de economia de cada país.
    </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Urbanização
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O tema referente à urbanização abrange assuntos relacionados ao crescimento da área urbana das cidades brasileiras
        aliado à falta de estrutura para receber esse grande contingente populacional, o que leva a problemas ambientais e sociais.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Energia Elétrica
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">São diversos os processos para a produção de energia no Brasil. É importante que os estudantes saibam quais
        são os principais tipos de fontes de energia que participam da matriz energética brasileira, como a eólica, a hidráulica, a biomassa,
        a solar e a das marés. É necessário conhecer as características dessas fontes de energia, saber como cada uma delas
        é obtida e quais são as consequências do uso destas para o meio ambiente.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Problemas Ambientais
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Problemas ambientais são assuntos abordados com grande frequência no ENEM e nos vestibulares, não somente em questões
        relacionadas à disciplina de geografia, mas em todas as áreas do conhecimento. Isso ocorre porque esse é um assunto atual
        que envolve diversas potências mundiais. É importante que os alunos entendam quais são as causas e consequências
        dos problemas ambientais para os seres humanos. É aconselhável ainda que os estudantes conheçam os acordos feitos para
        tentar amenizar os problemas ambientais, como o Rio +10 e o Protocolo de Kyoto.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Clima
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Elementos climáticos (como pressão atmosférica, umidade, temperatura, fatores que determinam o clima, mudanças
        climáticas e as suas consequências) são assuntos cobrados com frequência nos vestibulares e no ENEM. É importante também que o
        aluno esteja por dentro de temas como o aquecimento global e a camada de ozônio, tendo ideia de como eles podem afetar o clima mundial.
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Teorias Demográficas
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Saber quais são as teorias demográficas Malthusiana, Neomalthusiana e Reformista e as principais características
        delas é o gancho para este assunto. Além disso, recomenda-se conhecer os erros das teorias demográficas e a
        volta da Teoria Malthusiana após a segunda guerra mundial. Podem aparecer questões que relacionam passagens do livro “O Inferno”, de Dan Brown,
        pois a obra discorre sobre a população.
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        Migrações Internacionais
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Esse é um assunto que exige cuidado, pois confunde os alunos e pode ser abordado de diversas maneiras. Esse tema inclusive já
        foi cobrado na redação do ENEM. Conhecer os novos fluxos migratórios, a motivação econômica e política destes migrantes, saber o que é
        xenofobia e como ela ocorre são os principais temas desta área. Pode ser abordada também a rota feita pelos haitianos para o Brasil,
        que é utilizada por migrantes de outras nacionalidades.
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
