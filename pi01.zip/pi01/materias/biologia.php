<?php include "./inc/header.php"; ?>
<h3>Biologia</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Citologia
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A Citologia ou Biologia Celular é o ramo da Biologia que estuda as células. A palavra citologia deriva do grego kytos,
        célula e logos, estudo. A citologia foca-se no estudo das células,
        abrangendo a sua estrutura e metabolismo. O nascimento da citologia e a invenção do microscópio são fatos relacionados.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Metabolismo Celular
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Metabolismo é o conjunto de transformações que as substâncias químicas sofrem no interior dos organismos vivos.
        A expressão metabolismo celular é usada em referência ao conjunto de todas as reações químicas que ocorrem nas células.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Histologia Animal
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A histologia é o ramo da Biologia que estuda os tecidos, sua origem embrionária, sua diferenciação celular,
        estrutura e funcionamento. Os animais são seres multicelulares, ou seja, constituídos por um grande número de células que trabalham de forma integrada.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Histologia Vegetal
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Histologia Vegetal é o estudo específico de tecidos vegetais. Tecidos Vegetais são grupos de
        células que geralmente realizam as mesmas funções. São divididos em meristemas e tecidos adultos.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Vírus
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Vírus é uma partícula basicamente proteica que pode infectar organismos vivos. Vírus são parasitas
        obrigatórios do interior celular e isso significa que eles somente se reproduzem pela invasão e possessão do controle da maquinaria de auto-reprodução celular.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Reino Monera
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Monera é um reino biológico que inclui todos os organismos vivos que possuem uma organização celular procariótica,
        como bactérias, cianobactérias e arqueobactérias.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Reino Animal
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Animalia, Animal ou Metazoa é um reino biológico composto por seres vivos pluricelulares, Eucariontes, heterotróficos,
        cujas células formam tecidos biológicos, com capacidade de responder ao ambiente (possuem tecido nervoso) que os envolve ou, por outras palavras, pelos animais.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        Reino Vegetal
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O Reino Vegetal (Plantae, Metaphyta ou Vegetabilia) é composto por seres vivos eucariontes e autótrofos – que produzem
        o próprio alimento. As plantas, representantes desse reino, possuem diversos tamanhos, que vão desde os pequenos musgos até as gigantes sequoias.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
        Genética
      </button>
    </h2>
    <div id="flush-collapseNine" class="accordion-collapse collapse" aria-labelledby="flush-headingNine" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A Genética é uma parte da Biologia que estuda, principalmente, como ocorre a transmissão de características
        de um organismo aos seus descendentes. Sendo assim, podemos dizer, resumidamente, que ela é uma ciência que se
        volta para o estudo da hereditariedade, preocupando-se também com a análise dos genes.
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
