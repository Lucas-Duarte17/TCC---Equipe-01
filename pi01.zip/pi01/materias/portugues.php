<?php include "./inc/header.php"; ?>
<h3>Português</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Substantivo
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O substantivo ou nome é uma classe de palavras variável com que se designam ou se nomeiam os
        seres em geral ou são as palavras variáveis com que se designam os seres.
        O substantivo é a palavra que serve, de modo primário, de núcleo de sujeito, do objeto direto,
        do objeto indireto e do agente da passiva.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Adjetivo
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Adjetivo é toda palavra que se refere a um substantivo indicando-lhe um atributo. Flexionam-se em gênero, número e/ou grau.
        Sua função gramatical pode ser comparada com a do advérbio em relação aos verbos, aos adjetivos e a outros advérbios.
        Exemplos: O pássaro é lindo; A mulher é bonita; A mãe é inteligente.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        Artigo
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Dá-se o nome de artigo às palavras que se antepõem aos substantivos para indicar se esses têm um sentido individual,
        já determinado pelo discurso ou pelas circunstâncias, chamados definidos, ou se os substantivos não são determinados, chamados indefinidos.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        Pronome
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Na Linguística, os pronomes são um conjunto fechado de palavras de uma língua que podem substituir,
        modificar ou retomar substantivos variados, ou frases derivadas deles, na formação de sentenças , tratando-se de um tipo particular de proforma.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Verbo
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Um verbo é uma palavra que indica acontecimentos representados no tempo, como uma ação, um estado, um processo ou um fenômeno.
        Os verbos flexionam-se em número, pessoa, modo, tempo, aspecto e voz. As orações e os períodos desenvolvem-se em torno de um verbo.
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Orações
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">A oração é uma unidade sintática. Trata-se de um enunciado linguístico cuja estrutura caracteriza-se, obrigatoriamente,
        pela presença de um verbo. Na verdade, a oração é caracterizada, sintaticamente, pela presença de um predicado, o qual é
        introduzido na língua portuguesa pela presença de um verbo.
      </div>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
