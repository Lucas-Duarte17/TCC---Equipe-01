<?php include "./inc/header.php"; ?>
<h3>Física</h3>
<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Termologia
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Termologia é o estudo científico dos fenômenos relacionados ao calor e à temperatura, como transferência de calor, equilíbrio térmico, transformações sofridas por gases, mudanças de estado físico, etc.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Movimento Circular
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Movimento circular é o movimento de rotação de um corpo em torno de um eixo ao longo de uma trajetória circular de raio constante. Esse movimento pode ser uniforme, caso a velocidade de rotação seja constante, ou variado, caso sua velocidade sofra variações ao longo do tempo.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        MRU
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Movimento Retilíneo Uniforme (MRU) é o movimento que ocorre com velocidade constante em uma trajetória reta. Desta forma, em intervalos de tempos iguais o móvel percorre a mesma distância.
        Um exemplo de MRU é quando estamos viajando em uma estrada plana e reta e o velocímetro indica sempre a mesma velocidade.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        MRUV
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">O Movimento Retilíneo Uniformemente Variado (MRUV) é aquele que é realizado em linha reta, por
        isso é chamado de retilíneo. Além disso, apresenta variação de velocidade sempre nos mesmos intervalos de tempo. Uma vez
        que varia da mesma forma, o que revela constância, o movimento é chamado de uniformemente variado.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        Óptica
      </button>
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Óptica é a parte da Física responsável pelo estudo dos fenômenos associados à luz. Os fenômenos
        relacionados à Óptica são conhecidos desde a Antiguidade. Existem registros de que, em 2.283 a.C., já eram utilizados cristais
        de rocha para observar as estrelas. Na Idade Antiga, na Assíria, já havia a lente de cristal; e, na Grécia, utilizava-se a
        lente de vidro para obter fogo.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSix">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
        Aceleração
      </button>
    </h2>
    <div id="flush-collapseSix" class="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Aceleração é uma grandeza física vetorial e a sua unidade é o m/s². A aceleração mede a mudança
        da velocidade em relação ao tempo. Portanto, podemos afirmar que aceleração é a taxa de variação temporal da velocidade de
        um móvel.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingSeven">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
        Velocidade
      </button>
    </h2>
    <div id="flush-collapseSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingSeven" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Em Física, velocidade é a relação entre uma determinada distância percorrida e o tempo gasto para
        percorrer esta distância. Este trajeto é medido em metros e o tempo em segundo (m/s), no SI (Sistema Internacional de
        Unidades), também pode ser convertido para quilômetros para a distância, e horas para o tempo gasto.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingEight">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
        Ondas
      </button>
    </h2>
    <div id="flush-collapseEight" class="accordion-collapse collapse" aria-labelledby="flush-headingEight" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">As ondas são perturbações que se propagam pelo espaço sem transporte de matéria, apenas de energia.
        O elemento que provoca uma onda é denominado fonte, por exemplo, uma pedra lançada nas águas de um rio gerarão ondas circulares.
        São exemplos de ondas: ondas do mar, ondas de rádio, som, luz, raio-x, micro-ondas dentre outras.
        A parte da Física que estuda as ondas e suas características é chamada de ondulatória.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingNine">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
        Acústica
      </button>
    </h2>
    <div id="flush-collapseNine" class="accordion-collapse collapse" aria-labelledby="flush-headingNine" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Acústica é a uma área de estudo da Física que estuda todos os aspectos relacionados às
        ondas mecânicas, como o som, o ultrassom e as vibrações que se propagam em meios sólidos, líquidos e gasosos. Ela se
        concentra no estudo de fenômenos como a propagação, reflexão, absorção e interferência entre ondas sonoras.
      </div><br><br>
    </div>
  </div>
</div>
<?php include "./inc/footer.php"; ?>
