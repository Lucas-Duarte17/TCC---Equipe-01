<?php
/*
configuração do acesso ao bd
*/
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'dsweb');
/*
estabelecimento da conexão com o bd
paradigma procedural
não foi utilizado OO
*/
$link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
/*
teste da conexão
*/
if($link === false){
    die("ERRO: Não foi possível conectar ao Banco de Dados. " . mysqli_connect_error());
}
?>
