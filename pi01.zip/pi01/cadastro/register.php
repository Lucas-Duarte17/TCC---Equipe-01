<?php
// importação do arquivo config.php
require_once "config.php";

// criação das variáveis para controle de acesso
$username             = "";
$password             = "";
$confirm_password     = "";
$username_err         = "";
$password_err         = "";
$confirm_password_err = "";
$nome                 ="";
$nome_err             ="";
$email                ="";
$email_err            ="";
$telefone             ="";
$telefone_err         ="";


// testa se o método utilizado foi o POST
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // valida o nome do usuário
    if(empty(trim($_POST["username"]))){
        $username_err = "Por favor entre com seu nome de usuário (login).";
    } else{
        // prepara a query para execução
        $sql = "SELECT id FROM usuarios WHERE login = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // define o parâmetro
            $param_username = trim($_POST["username"]);

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // guarda o resultado
                mysqli_stmt_store_result($stmt);
                // verifica se o usuário existe
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "Este usuário já existe.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query preparada
            mysqli_stmt_close($stmt);
        }
    }

    // validação da senha
    if(empty(trim($_POST["password"]))){
        $password_err = "Por favor entre com a senha.";
    } elseif(strlen(trim($_POST["password"])) < 4){
        $password_err = "A senha deve ter ao menos 04 caracteres.";
    // verificar se as senhas contem numero e letra
      } elseif(!preg_match('/[A-Za-z]/', ($_POST["password"])) || !preg_match('/[0-9]/', ($_POST["password"]))) {
        $password_err = "A senha deve conter números e letras.";
      } else{
        $password = trim($_POST["password"]);
    }

    // Confirmação da senha
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Por favor confirme a senha.";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "As senhas digitadas são diferentes.";
        }
    }

    if(empty(trim($_POST["nome"]))){
        $nome_err = "Por favor insira o seu nome completo.";
    } else{
        // prepara a query para execução
        $sql = "SELECT id FROM usuarios WHERE nome = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "s", $param_nome);

            // define o parâmetro
            $param_nome = trim($_POST["nome"]);

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // guarda o resultado
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $nome_err = "Esse nome já possui uma conta.";
                } else{
                    $nome = trim($_POST["nome"]);
                }
            } else{
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query preparada
            mysqli_stmt_close($stmt);
        }
    }

    if(empty(trim($_POST["email"]))){
        $email_err = "Por favor insira o seu email.";
    } else{
        // prepara a query para execução
        $sql = "SELECT id FROM usuarios WHERE email = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            // define o parâmetro
            $param_email = trim($_POST["email"]);

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // guarda o resultado
                mysqli_stmt_store_result($stmt);
                // verifica se o usuário existe
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $email_err = "Email já cadastrado.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query preparada
            mysqli_stmt_close($stmt);
        }
    }

    if(empty(trim($_POST["telefone"]))){
        $telefone_err = "Por favor insira o seu número de telefone.";
    } else{
        // prepara a query para execução
        $sql = "SELECT id FROM usuarios WHERE telefone = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "s", $param_telefone);

            // define o parâmetro
            $param_telefone = trim($_POST["telefone"]);

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // guarda o resultado
                mysqli_stmt_store_result($stmt);
                // verifica se o usuário existe
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $telefone_err = "Esse telefone já existe.";
                } else{
                    $telefone = trim($_POST["telefone"]);
                }
            } else{
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query preparada
            mysqli_stmt_close($stmt);
        }
    }

    // checa erros de entrada antes de inserir no bd
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($nome_err) && empty($email_err) && empty($telefone_err)){
        // prepara a query de inclusão
        $sql = "INSERT INTO usuarios (login, password, nome, email, telefone) VALUES (?, ?, ?, ?, ?)";
        echo "Realizou a preparação <br>";
        var_dump($stmt);

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "sssss", $param_username, $param_password, $param_nome, $param_email, $param_telefone);

            // define o parâmetro
            $param_username = $username;

            //  cria um hash para a senha
            $param_password = password_hash($password, PASSWORD_DEFAULT);

            $param_nome = $nome;

            $param_email = $email;

            $param_telefone = $telefone;

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // redireciona para página de login
                header("location: login.php");
            } else{
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query
            mysqli_stmt_close($stmt);
        }
    }

    // encerra a conexão
    mysqli_close($link);
}
?>

<?php include "./inc/header.php"; ?>
<div class="wrapper">
    <h2>Registre-se</h2>
    <p>Por favor, preencha este formulário para criar sua conta.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
            <label>Nome de Usuário (login)</label>
            <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
            <span class="help-block"><?php echo $username_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
            <label>Senha</label>
            <input type="password" name="password" class="form-control" value="<?php echo $password; ?>">
            <span class="help-block"><?php echo $password_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
            <label>Confirme a senha</label>
            <input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>">
            <span class="help-block"><?php echo $confirm_password_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($nome_err)) ? 'has-error' : ''; ?>">
            <label>Nome completo</label>
            <input type="text" name="nome" class="form-control" value="<?php echo $nome; ?>">
            <span class="help-block"><?php echo $nome_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
            <label>Email</label>
            <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
            <span class="help-block"><?php echo $email_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($telefone_err)) ? 'has-error' : ''; ?>">
            <label>Telefone</label>
            <input type="text" name="telefone" class="form-control" value="<?php echo $telefone; ?>">
            <span class="help-block"><?php echo $telefone_err; ?></span>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Enviar">
            <input type="reset" class="btn btn-default" value="Limpar">
        </div>
        <p>Já possui uma conta? <a href="login.php">Faça o login aqui</a>.</p>
        <a class="btn btn-link" href="../index.php">Cancelar</a>
    </form>
</div>
  </body>
</html>
