<?php
// inicializa a sessão
session_start();

/*
verifica se o usuário está logado,se estiver redireciona para a página de boas vindas
*/
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: ../login.php");
    exit;
}

// importa do arquivo de configuração
require_once "config.php";

// cria e inicializa as variáveis com ""
$username = $password = "";
$username_err = $password_err = "";

// testa se o método utilizado foi o POST
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // verifica se o login do Usuário está vazio
    if(empty(trim($_POST["username"]))){
        $username_err = "Por favor entre com o login.";
    } else{
        $username = trim($_POST["username"]);
    }

    // verifica se a senha do usuário está vazia
    if(empty(trim($_POST["password"]))){
        $password_err = "Por favor entre com a senha.";
    } else{
        $password = trim($_POST["password"]);
    }

    // valida os dados so usuário
    if(empty($username_err) && empty($password_err)){

        // prepara a query de consulta
        $sql = "SELECT id, login, password FROM usuarios WHERE login = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // vincula as variáveis à instrução preparada com parâmetros
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // define o parâmetro
            $param_username = $username;

            // executa a query preparada
            if(mysqli_stmt_execute($stmt)){
                // guarda o resultado
                mysqli_stmt_store_result($stmt);

                // verifica se o usuário existe, se existir verifica a senha
                if(mysqli_stmt_num_rows($stmt) == 1){
                    // vincula as variáveis aos resultados
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    // Obtém resultados de um preparado comando e os coloca nas determinadas variáveis
                    if(mysqli_stmt_fetch($stmt)){
                        // testa a senha (c/ alg. Hash)
                        if(password_verify($password, $hashed_password)){
                            // senha ok, inicia a sessão
                            session_start();

                            // armazena os dados nas variáveis de sessão.
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;

                            // redireciona para a página de boas vindas
                            header("location: ../perfil/index.php");
                        } else{
                            // informa que a senha não é válida
                            $password_err = "A senha digitada não é válida.";
                        }
                    }
                } else{
                    // informa que o usuário não existe
                    $username_err = "O usuário digitado não existe.";
                }
            } else {
                echo "Desculpe! Algo errado aconteceu. Por favor tente novamente.";
            }

            // fecha a query
            mysqli_stmt_close($stmt);
        }
    }

    // encerra a conexão
    mysqli_close($link);
}
?>


<?php include "./inc/header.php"; ?>
    <div class="wrapper">
        <h2>Login</h2>
        <p>Por favor preencha seus dados para login.</p>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Usuário (login)</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Senha</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Não tem ainda? <a href="register.php">Cadastre-se agora</a>.</p>
            <br><a class="btn btn-link" href="../index.php">Cancelar</a>
        </form>
    </div>
  </body>
</html>
