<?php
    // incluir a funcionalidade do recaptcha
    require_once("recaptchalib.php");
    use PHPMailer\PHPMailer\PHPMailer;

    // definir a chave secreta
    $secret = "6LcBEz8aAAAAAMb6QveKVheJWzgNuuYApqLKb5-1";

    // verificar a chave secreta
    $response = null;
    $reCaptcha = new reCaptcha($secret);

    if ($_POST["g-recaptcha-response"]) {
      $response = $reCaptcha->verifyResponse($_SERVER["REMOTE_ADDR"], $_POST["g-recaptcha-response"]);
    }

    // deu tudo certo?
    if ($response != null && $response->success) {

      $nome=$_POST['nome'];
      $telefone=$_POST['telefone'];
      $email=$_POST['email'];
      $date=date("d/m/Y");
      $msg=$_POST['mensagem'];
      // formatando nossa mensagem (que será envaida ao e-mail)
      $mensagem= 'Esta mensagem foi enviada através do formulário<br><br>';
      $mensagem.='<b>Nome: </b>'.$nome.'<br>';
      $mensagem.='<b>Telefone:</b> '.$telefone.'<br>';
      $mensagem.='<b>E-Mail:</b> '.$email.'<br>';
      $mensagem.='<b>Data de envio:</b> '.$date.'<br>';
      $mensagem.='<b>Mensagem:</b><br> '.$msg;

      require_once "PHPMailer/PHPMailer.php";
      require_once "PHPMailer/SMTP.php";
      require_once "PHPMailer/Exception.php";

      $mail = new PHPMailer();

      //config smtp
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = true;
      $mail->Username = '@gmail.com';
      $mail->Password = '';
      $mail->Port = 465;
      $mail->SMTPSecure = 'ssl';

      //config email
      $mail->isHTML(true);
      $mail->setFrom($email, $nome);
      $mail->addAddress('@gmail.com');
      $mail->Subject = ("Formulário");
      $mail->Body = $mensagem;

      if(!$mail->Send()) {
        echo "<script>alert('Erro ao enviar o E-Mail');window.location.assign('index.php');</script>";
       }else{
         echo "<script>alert('E-Mail enviado com sucesso!');window.location.assign('index.php');</script>";
       }
    }
	  // Caso o Captcha não tenha sido validado
	  //retorno uma mensagem de erro.
	  else {
		  echo "Por favor faça a verificação do captcha abaixo";
	  }
?>
