</main> <!-- /container -->
<nav class="navbar fixed-bottom navbar-dark bg-dark text-muted d-none d-lg-block">
  <div class="container-fluid">
    <h7>Todos os Direitos Reservados ParaSaberMaisConteúdosDigitais Ltda&#169;</h7><br>
    <h7>Desenvolvido utilizando HTML, CSS, PHP e JS, pela <b>InovaTech&#169;</b></h7>
    <a href="../fontes.php" style="text-decoration: none; color: #33aafe;">Fontes</a>
  </div>
</nav>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo BASEURL; ?>js/jquery-1.11.2.min.js"><\/script>')</script>
  <script src="../bootstrap/500/js/bootstrap.min.js"></script>
</body>
</html>
