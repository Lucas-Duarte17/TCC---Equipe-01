<?php include "./inc/header.php"; ?>
  <div class="postagem">
    <div>
      <h2>Fontes das matérias de matemática:</h2>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Opera%C3%A7%C3%A3o_(matem%C3%A1tica)">Wikipedia - Operações Básicas</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/%C3%81rea#:~:text=%C3%81rea%20%C3%A9%20um%20conceito%20matem%C3%A1tico,seus%20m%C3%BAltiplos%20e%20sub%2Dm%C3%BAltiplos.">Wikipedia - Área</a></p>
      <p><a target="_blank" href="https://mundoeducacao.uol.com.br/matematica/geometria-espacial.htm#:~:text=A%20geometria%20espacial%20%C3%A9%20a,%2C%20reta%2C%20plano%20e%20espa%C3%A7o.">Mundo Educação - Geometria Espacial</a></p>
      <p><a target="_blank" href="https://www.stoodi.com.br/blog/matematica/formulas-pa-e-pg/#:~:text=tema%20da%20matem%C3%A1tica!-,O%20que%20s%C3%A3o%20PA%20e%20PG%3F,enquanto%20PG%20significa%20progress%C3%A3o%20geom%C3%A9trica.">Stoodi - PA e PG</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/matematica/angulos.htm#:~:text=%C3%82ngulos-,Matem%C3%A1tica,poss%C3%ADveis%20unidades%3A%20grau%20ou%20radiano.&text=Quando%20a%20soma%20entre%20eles,%C3%A2ngulos%20complementares%2C%20suplementares%20e%20replementares.">Brasil Escola - Ângulos</a></p>
      <p><a target="_blank" href="https://www.coladaweb.com/matematica/circunferencia">Cola da Web - Circunferência</a></p>
      <p><a target="_blank" href="https://matematicabasica.net/trigonometria/#:~:text=Trigonometria%20%C3%A9%20a%20%C3%A1rea%20da,raz%C3%B5es%20seno%2C%20cosseno%20e%20tangente.">Mtatemática Básica - Trigonometria</a></p>
      <p><a target="_blank" href="https://www.todamateria.com.br/potenciacao/">Toda Matéria - Potenciação</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/o-que-e/matematica/o-que-e-funcao.htm#:~:text=Uma%20fun%C3%A7%C3%A3o%20%C3%A9%20uma%20rela%C3%A7%C3%A3o,(representado%20pela%20vari%C3%A1vel%20y).">Brasil Escola - Funções</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de física:</h2>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/termologia.htm#:~:text=Termologia%20%C3%A9%20o%20estudo%20cient%C3%ADfico,mudan%C3%A7as%20de%20estado%20f%C3%ADsico%2C%20etc.">Brasil Escola - Termologia</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/movimento-circular.htm#:~:text=Movimento%20circular%20%C3%A9%20o%20movimento,varia%C3%A7%C3%B5es%20ao%20longo%20do%20tempo.">Brasil Escola - Movimento Circular</a></p>
      <p><a target="_blank" href="https://www.todamateria.com.br/movimento-retilineo-uniforme/">Toda Matéria - MRU</a></p>
      <p><a target="_blank" href="https://www.todamateria.com.br/movimento-retilineo-uniformemente-variado/">Toda Matéria - MRUV</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/optica.htm">Brasil Escola - Óptica</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/aceleracao.htm">Brasil Escola - Aceleração</a></p>
      <p><a target="_blank" href="https://blogdoenem.com.br/fisica-enem-velocidade/#:~:text=Em%20F%C3%ADsica%2C%20velocidade%20%C3%A9%20a,horas%20para%20o%20tempo%20gasto.">Blog do Enem - Velocidade</a></p>
      <p><a target="_blank" href="https://www.todamateria.com.br/ondas/">Toda Matéria - Ondas</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/acustica.htm">Brasil Escola - Acústica</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de química:</h2>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Eletroqu%C3%ADmica">Wikipedia - Eletroquímica</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Fun%C3%A7%C3%B5es_org%C3%A2nicas">Wikipedia - Funções Orgânicas</a></p>
      <p><a target="_blank" href="https://mundoeducacao.uol.com.br/quimica/as-funcoes-inorganicas.htm">Mundo Educação - Funções Inorgânicas</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/quimica/gases.htm#:~:text=Os%20gases%20s%C3%A3o%20subst%C3%A2ncias%20cujas,est%C3%A3o%20sempre%20em%20movimento%20desordenado.&text=Um%20g%C3%A1s%2C%20seja%20ele%20qual,volume%2C%20temperatura%20e%20de%20press%C3%A3o">Brasil Escola - Gases</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/quimica/estequiometria-reacoes.htm#:~:text=Estequiometria%20%C3%A9%20o%20c%C3%A1lculo%20da,e%20metron%20%3D%20medida%20ou%20medi%C3%A7%C3%A3o">Brasil Escola - Estequiometria</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/o-que-e/quimica/o-que-e-atomo.htm#:~:text=Esse%20nome%20foi%20proposto%20pelos,a%20menor%20parte%20da%20mat%C3%A9ria.">Brasil Escola - Átomo</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Estados_f%C3%ADsicos_da_mat%C3%A9ria">Wikipedia - Estados Físicos</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de biologia:</h2>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/biologia/conceitos-basicos-genetica.htm">Brasil Escola - Genética</a></p>
      <p><a target="_blank" href="https://www.educamaisbrasil.com.br/enem/biologia/reino-vegetal">Educa Mais - Reino Vegetal</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Animalia">Wikipedia - Reino Animal</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Monera">Wikipedia - Reino Monera</a></p>
      <p><a target="_blank" href="https://www.sobiologia.com.br/conteudos/Seresvivos/Ciencias/biovirus.php#:~:text=V%C3%ADrus%20%C3%A9%20uma%20part%C3%ADcula%20basicamente,maquinaria%20de%20auto%2Dreprodu%C3%A7%C3%A3o%20celular">Só Biologia - Vírus</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Histologia_vegetal">Wikipedia - Histologia Vegetal</a></p>
      <p><a target="_blank" href="https://www.todamateria.com.br/histologia-animal/#:~:text=A%20histologia%20%C3%A9%20o%20ramo,que%20trabalham%20de%20forma%20integrada">Toda Matéria - Histologia Animal</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Metabolismo">Wikipedia - Metabolismo Celular</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de português:</h2>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Substantivo">Wikipedia - Substantivo</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Adjetivo">Wikipedia - Adjetivo</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Artigo_(gram%C3%A1tica)">Wikipedia - Artigo</a></p>
      <p><a target="_blank" href="https://pt.wikipedia.org/wiki/Pronome">Wikipedia - Pronome</a></p>
      <p><a target="_blank" href="https://www.conjugacao.com.br/verbo/">Conjugação - Verbo</a></p>
      <p><a target="_blank" href="https://www.portugues.com.br/gramatica/frase-oracao-periodo.html">Português - Orações</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de literatura:</h2>
      <p><a target="_blank" href="https://www.educamaisbrasil.com.br/enem/lingua-portuguesa/escolas-literarias">Educa Mais - Escolas Literárias</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de história:</h2>
      <p><a target="_blank" href="https://www.unicesumar.edu.br/blog/curso-de-historia/">Unicesumar - História</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes das matérias de geografia:</h2>
      <p><a target="_blank" href="https://www.mundovestibular.com.br/estudos/geografia/os-10-temas-de-geografia-que-voce-precisa-entender/">Mundo Vestibular - Geografia</a></p>
      <hr>
    </div>
    <div>
      <h2>Fontes da área restrita:</h2>
      <p><a target="_blank" href="https://www.todamateria.com.br/areas-de-figuras-planas/">Toda Matéria</a></p>
      <p><a target="_blank" href="https://www.youtube.com/watch?v=ufA5Vkc2aDM">YouTube</a></p>
      <p><a target="_blank" href="https://www.stoodi.com.br/blog/matematica/formulas-pa-e-pg/#:~:text=tema%20da%20matem%C3%A1tica!-,O%20que%20s%C3%A3o%20PA%20e%20PG%3F,enquanto%20PG%20significa%20progress%C3%A3o%20geom%C3%A9trica">Stoodi</a></p>
      <p><a target="_blank" href="https://www.stoodi.com.br/blog/fisica/termologia/">Stoodi</a></p>
      <p><a target="_blank" href="https://www.youtube.com/watch?v=mqjWQYX6hxs">YouTube</a></p>
      <p><a target="_blank" href="https://brasilescola.uol.com.br/fisica/ondas.htm">Brasil Escola</a></p>
      <hr>
    </div>
    <div>
      <h2>Imagens e Ícones</h2>
      <div>Ícones feitos por <a target="_blank" href="https://www.flaticon.com/br/autores/vectors-market" title="Vectors Market">Vectors Market</a> from <a target="_blank" href="https://www.flaticon.com/br/" title="Flaticon">www.flaticon.com</a></div>
      <div>Ícones feitos por <a target="_blank" href="https://www.flaticon.com/br/autores/monkik" title="monkik">monkik</a> from <a target="_blank" href="https://www.flaticon.com/br/" title="Flaticon">www.flaticon.com</a></div>
      <div>Icons made by <a target="_blank" href="https://www.freepik.com" title="Freepik">Freepik</a> from <a htarget="_blank" ref="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
      <a target="_blank" href='https://br.freepik.com/fotos/fundo'>Fundo foto criado por jcomp - br.freepik.com</a>
      <a target="_blank" href='https://br.freepik.com/vetores/escola'>Escola vetor criado por vectorjuice - br.freepik.com</a>
      <a target="_blank" href='https://br.freepik.com/fotos/educacao'>Educação foto criado por freepik - br.freepik.com</a>
      <hr>
    </div>
    <div>
      <h2>Jogo do Playground</h2>
      <h4>Tilting Maze game</h4>
      <p>Criado no CodePen.io. Original URL: <a target="_blank" href="https://codepen.io/HunorMarton/pen/VwKwgxX">CodePen-HunorMarton</a>
        <br>Se você quer saber como o jogo funciona, você pode descobrir lá no youtube: <a target="_blank" href="https://youtu.be/bTk6dcAckuI">https://youtu.be/bTk6dcAckuI</a>
        <br>"Follow me on <a target="_blank" href="https://twitter.com/HunorBorbely">twitter</a>"</p>
    </div>
  </div><br><br>

<?php include "./inc/footer.php"; ?>
